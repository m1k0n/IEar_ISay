package Model;

import java.util.ArrayList;
import java.util.Collection;



/**
 * Contain all of the boxes, we use it to shuffle without losing informations.
 *
 */

public class Grid {
	private int height;
	private int length;
	
	public Grid(int height, int length){
		this.height=height;
		this.length=length;
	}
}
